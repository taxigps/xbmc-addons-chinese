#Author is Caasiu, @Copyright 2016
#Email: caasiu@outlook.com
#GNU GENERAL PUBLIC LICENSE Version 3, GPLv3 
