#!/usr/bin/python
# -*- coding: utf-8 -*-
#Author is Caasiu <caasiu@outlook.com> @Copyright 2016

#This Crypto module has been modified for kodi addon, the original one is Legrandin/pycryptodome
#This module is for password encryption using the given public key
#Under GNU GENERAL PUBLIC LICENSE Version 3, GPLv3 

#该模块修改自 Legrandin/pycryptodome
#该模块是用于对用户的密码进行加密，然后再发送到服务器
