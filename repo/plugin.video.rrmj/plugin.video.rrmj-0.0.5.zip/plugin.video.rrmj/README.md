# plugin.video.rrmj

## todo list
- [ ] auto play next episode
- [ ] download and store
- [ ] search
- [ ] history
