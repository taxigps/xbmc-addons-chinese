# plugin.video.rrmj

## todo list
- [x] auto play next episode
- ~~设置-->视频-->播放-->自动播放下一个视频~~
- ~~Settings-->Video-->Playback-->Play next video automatically~~
- [ ] download and store
- [x] search
- [x] history
