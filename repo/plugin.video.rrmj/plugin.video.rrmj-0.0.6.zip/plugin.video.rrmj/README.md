# plugin.video.rrmj

## todo list
- [x] auto play next episode
- [ ] download and store
- [x] search
- [ ] history
