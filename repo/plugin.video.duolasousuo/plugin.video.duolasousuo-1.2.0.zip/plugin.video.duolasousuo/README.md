# plugin.video.duolasousuo

> 哆啦搜索（Kodi视频插件）

本插件基于爬虫技术，利用Kodi为计算平台进行测试和练习Python技术，仅供阁下学习和测试，请勿用于其他用途。