# plugin.video.cntv-replay
 央视重播 CCTV Replay
 按北京时间重播比直播晚十到十五分钟。
 
