# plugin.video.douyu2
Simple douyutv video plugin for kodi

===

This is a video plugin for [Kodi](http://kodi.tv) mediacenter.

License: [GPL v.3](http://www.gnu.org/copyleft/gpl.html)
